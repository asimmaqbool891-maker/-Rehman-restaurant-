# Rehman Restaurant Website

A responsive, single-page restaurant menu website built with HTML, CSS, and vanilla JavaScript.

## Features

- Responsive layout for desktop, tablet, and mobile screens
- Dark charcoal and gold restaurant theme
- Menu categories: Traditional Desi, Gourmet Fast Food, Fresh Juices & Lassi
- Live menu search
- Category filter buttons
- Click-to-call links
- WhatsApp order links for individual dishes
- SEO description and Google site-verification meta tag
- No build tools or package installation required

## Project files

```text
rehman-restaurant-website/
├── index.html
├── README.md
├── .gitignore
└── LICENSE
```

## Run locally

1. Download or clone this repository.
2. Open `index.html` in a browser.

For a local development server, you can use the VS Code Live Server extension, but it is optional.

## Deploy with GitHub Pages

1. Push these files to a GitHub repository.
2. Open the repository on GitHub.
3. Go to **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)` folder, then save.
6. Wait for GitHub Pages to publish the site. The live URL will appear in the Pages settings.

## Update restaurant details

Before publishing, verify that the restaurant details are correct:

- **Phone:** `0303-3754370`
- **WhatsApp:** `923033754370` (international format, without the leading `+`)
- **Location:** `Waqar Petrol Pump, Near Khuharo Stop`
- **Menu prices:** Confirm current prices with the restaurant.

To update the phone number or WhatsApp number, search in `index.html` for `03033754370` or `923033754370` and replace all relevant occurrences. WhatsApp ordering requires WhatsApp to be active on the configured number.

## Images and fonts

The website loads menu images from Unsplash and fonts from Google Fonts. An internet connection is needed for these remote assets. Replace the image URLs in `index.html` with restaurant-owned photos for a more authentic menu. Check image suitability and usage terms before commercial use.

## Important notes

- The menu prices are the values provided for this website and should be verified before going live.
- The website link `https://www.rehmanrestaurant.com` is displayed as provided; confirm that the domain is owned and configured by the restaurant.
- The Google site-verification meta tag has been retained from the original HTML. Keep it only if it belongs to the correct Google Search Console property.
- This is a front-end website. WhatsApp buttons open a pre-filled message; they do not process payments or automatically confirm orders.
- No customer data is stored by this website.

## Technology

- HTML5
- CSS3
- Vanilla JavaScript
